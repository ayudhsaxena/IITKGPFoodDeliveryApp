package com.example.onlinefooddeliveryapp.Activities;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.onlinefooddeliveryapp.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.List;

public class login extends AppCompatActivity {

    public static final String PASSWORD = "password";
    public static final String USERNAME = "username";
    public static final String TAG = "Login";
    private CollectionReference collRef = FirebaseFirestore.getInstance().collection("users");

    public void userLogin(View view){

        EditText unameText =  findViewById(R.id.unameTextId);
        EditText pwdText =  findViewById(R.id.pwdTextId);
        final TextView errorText = findViewById(R.id.errorTextView);
        errorText.setText(null);

        String uname = unameText.getText().toString();
        final String pwd = pwdText.getText().toString();

        Query fetchPass = collRef.whereEqualTo(USERNAME,uname);
        fetchPass.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                if(task.isSuccessful()){
                    if(task.getResult().isEmpty()){
                        errorText.setText(R.string.missingUsername);
                    }
                    else{
                        List<DocumentSnapshot> res = task.getResult().getDocuments();
                        Log.d(TAG,pwd+" "+res.get(0).get(PASSWORD));
                        if(res.get(0).get(PASSWORD).equals(pwd)){
                            Log.d(TAG,"Successful Login!");
                        }
                        else{
                            errorText.setText(R.string.incorrectPassword);
                        }
                    }
                }
            }
        });


    }

    public void initiateSignUp(View view){
        Log.d("go","MOve!!");
        Intent intent = new Intent(this,SignUp.class);
        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Intent intent = getIntent();





    }
}
