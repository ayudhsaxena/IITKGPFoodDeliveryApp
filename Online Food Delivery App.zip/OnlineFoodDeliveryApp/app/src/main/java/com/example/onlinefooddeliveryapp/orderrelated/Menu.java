/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.example.onlinefooddeliveryapp.orderrelated;
import java.util.*;

/**
 *
 * @author Ayudh
 */
public class Menu {
    private ArrayList<foodItem> menuList;

    public Menu(ArrayList<foodItem> menuList) {
        this.menuList = menuList;
    }
    
    public Menu() {
      menuList = new ArrayList<>();
    }

    public ArrayList<foodItem> getMenuList() {
        return menuList;
    }

    public void setMenuList(ArrayList<foodItem> menuList) {
        this.menuList = menuList;
    }
    
    
    
}
